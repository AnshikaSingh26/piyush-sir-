//import the mongoose
const mangoose = require('mongoose');
//create schema
const Schema = mangoose.Schema;
// we need to declare the feilds
const locationschema = new Schema({
    name: {
        type: String,
        required: true
    },

    city_id: {
        type: Number,
        required: true

    },
    location_id: {
        type: Number,
        required: true

    },
    city_name: {
        type: String,
        required: true

    },
    country_name: {
        type: String,
        required: true

    }
});
// create a model from scheme and connect to mongodb
module.exports = mangoose.model('location', locationschema, 'location');
//mangoose.model('nameincontroller','nameofschema',mongodbcollectioname)