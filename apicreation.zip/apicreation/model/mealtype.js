//import the mongoose
const mangoose = require('mongoose');
//create schema
const Schema = mangoose.Schema;
// we need to declare the feilds
const mealtypeschema = new Schema({
    name: {
        type: String,
        required: true
    },

    _id: {
        type: Number,
        required: true

    },
    meal_type: {
        type: Number,
        required: true

    },
    image: {
        type: String,
        required: true

    },
    content: {
        type: String,
        required: true

    }
});
// create a model from scheme and connect to mongodb
module.exports = mangoose.model('mealtype', mealtypeschema, 'mealtype');
//mangoose.model('nameincontroller','nameofschema',mongodbcollectioname)