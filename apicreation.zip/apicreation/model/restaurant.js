//import the mongoose
const mangoose = require('mongoose');
//create schema
const Schema = mangoose.Schema;
// we need to declare the feilds
const restaurantschema = new Schema({
    _id: {
        type: Object,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    city_id: {
        type: Number,
        required: true
    },
    location_id: {
        type: Number,
        required: true
    },
    locality: {
        type: String,
        required: true
    },
    thumb: {
        type: Array,
        required: true
    },
    aggregate_rating: {
        type: Number,
        required: true
    },
    rating_text: {
        type: String,
        required: true
    },
    min_price: {
        type: Number,
        required: true
    },
    contact_number: {
        type: Number,
        required: true
    },
    cuisine: {
        type: Array,
        required: true
    },
    image: {
        type: String,
        required: true
    },
    meal_type_id: {
        type: Number,
        required: true
    },



});
// create a model from scheme and connect to mongodb
module.exports = mangoose.model('restaurants', restaurantschema, 'restaurants');
//mangoose.model('nameincontroller','nameofschema',mongodbcollectioname)