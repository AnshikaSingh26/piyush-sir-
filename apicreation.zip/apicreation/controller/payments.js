// const pay = require('../model/payment.json');
exports.payment = (req, res) => {

}
exports.paymentcallback = (req, res) => {

}