const user = require('../model/users');
exports.login = (req, res) => {
    const {
        username,
        password
    } = req.body
    user.find({
        email: username,
        password: password
    }).then(result => {
        if (result.length > 0) {
            res.status(200).json({
                message: "user found",
                isloggedin: true,
                user: result[0]
            })
        } else {
            res.status(400).json({
                message: "username or passwordis wrong",
                isloggedin: false
            })
        }

    }).catch(result => {
        res.status(500).json({
            message: "error in db",
            error: error
        })
    })
}
exports.signup = (req, res) => {
    const {
        email,
        password,
        firstName,
        lastName
    } = req.body;
    //create a new obj of the user model
    const userobj = new user({
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName
    });

    //save
    userobj.save().then(result => {
        res.status(200).json({
            message: "user registered successfully",
            user: result
        })
    }).catch(error => {
        res.status(500).json({
            message: "error in db",
            error: error
        })
    })
}