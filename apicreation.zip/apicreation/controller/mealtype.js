//import the model

const mealtype = require('../model/mealtype');


//export the controller functions
//getalllocations
exports.getallmealtypes = (req, res) => {
    mealtype.find().then(result => {
        res.status(200).json({
            message: "meal fetched",
            mealtype: result
        })
    }).catch(error => {
        res.status(500).json({
            message: "error in db",
            error: error
        })
    })
}