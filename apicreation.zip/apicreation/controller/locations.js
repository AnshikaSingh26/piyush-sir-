//import the model

const locations = require('../model/location');


//export the controller functions
//getalllocations
exports.getalllocations = (req, res) => {
    locations.find().then(result => {
        res.status(200).json({
            message: "location fetched",
            locations: result
        })
    }).catch(error => {
        res.status(500).json({
            message: "error in db",
            error: error
        })
    })
}