const { response } = require('express');
const restaurant = require('../model/restaurant');

//routes
// getallrestaurants
exports.getallrestaurants = (req, res) => {
        restaurant.find().then(result => {
            res.status(200).json({
                message: "restaurants fetched",
                restaurant: result
            })
        }).catch(error => {
            res.status(500).json({
                message: "error in db",
                error: error
            })
        })
    }
    // getallrestaurantsbylocation
exports.getallrestaurantsbylocation = (req, res) => {
        const cityname = req.params.cityname;
        restaurant.find({ city: cityname }).then(result => {
            res.status(200).json({
                message: "restaurants fetched by location" + cityname,
                restaurants: result
            })
        }).catch(error => {
            res.status(500).json({
                message: "error in db",
                error: error
            })
        })
    }
    // getallrestaurantsbyid
exports.getallrestaurantsbyid = (req, res) => {
        const restaurantid = req.params.restaurantid;
        restaurant.find({ _id: restaurantid }).then(result => {
            res.status(200).json({
                message: "restaurants fetched for " + restaurantid,
                restaurant: result[0] //will give one one result thats y
            })
        }).catch(error => {
            res.status(500).json({
                message: "error in db",
                error: error
            })
        })
    }
    // filterrestaurants based on mealtype,loc,cusine lcost hcost sort(l,h) pageno.
exports.filterrestaurants = (req, res) => {
    page = page ? page : 1;
    sort = sort ? sort : 1;
    const itemPerPage = 2;

    let startIndex = itemPerPage * page - itemPerPage;
    let endIndex = itemPerPage * page;
    const {
        mealtype,
        location,
        cuisine,
        lcost,
        hcost,
        sort,
        page = 1
    } = req.body;
    let filters = {};
    //add logic to apply filters
    if (mealtype) { filters.mealtype_id = mealtype; }
    if (location) { filters.location_id = location; }
    if (cuisine && cuisine.length > 0) { filters['cuisine.name'] = { $in } }
    if (hcost && lcost) {
        if (lcost == 0) {
            filters.min_price = { $lt: hcost }
        } else {
            filters.min_price = { $gt: lcost, $lt: hcost }
        }
    }

    restaurant.find(filters.sort({ min_price: sort })).then(result => {
        const filterdresponse = response.slice(startIndex, endIndex);
        res.status(200).json({
            message: "restaurants fetched for filters",
            restaurant: filterdresponse
        })
    }).catch(error => {
        res.status(500).json({
            message: "error in db",
            error: error
        })
    })
}