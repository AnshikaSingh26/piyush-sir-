// router from the express lib
const express = require('express');
const router = express.Router();

//import thr controllers
const locationController = require('../controller/locations');
const restaurantController = require('../controller/restaurants');
const mealtypeController = require('../controller/mealtype');
const userController = require('../controller/users')
const paymentController = require('../controller/payments');
const { get } = require('mongoose');

//declare the routes and bind to the controller methods

//restaurants
router.get('/getallrestaurants', restaurantController.getallrestaurants);
router.get('/getallrestaurantsbylocation/:cityname', restaurantController.getallrestaurantsbylocation); //notdone
router.get('/getallrestaurantsbyid/:restaurantid', restaurantController.getallrestaurantsbyid); //notdone
router.post('/filterrestaurants', restaurantController.filterrestaurants); //notdone

//locations
router.get('/getalllocations', locationController.getalllocations);

//mealtype
router.get('/getallmealtypes', mealtypeController.getallmealtypes);

//login,signup
router.post('/login', userController.login);
router.post('/signup', userController.signup);

//payments,paymentscallback
router.post('/payment', paymentController.payment);
router.post('/paymentcallback', paymentController.paymentcallback);

//export the router
module.exports = router;