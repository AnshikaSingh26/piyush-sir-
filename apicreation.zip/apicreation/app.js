//import the require pakage
const bodyParser = require('body-parser');
const express = require('express');
const mongoose = require('mongoose');
const port = 5454;

//creat routes folder
const routes = require('./route/route');

// initialise the lib
const app = express(); // starts express server
app.use(bodyParser.json());

// handle the CORS
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
    next();
});

// start using the route
app.use('/', routes);

//connect to mongoDb
mongoose.connect(
    'mongodb+srv://Anshika:Anshika@cluster0.tcdz0.mongodb.net/ZOMATO?retryWrites=true&w=majority', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    }
).then(success => {
    console.log("connected to db");
    // start the server
    app.listen(port, () => {
        console.log("server running port " + port);
    })
}).catch(error => {
    console.log("error");

});